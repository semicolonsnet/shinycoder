library(testthat)
test_package("shinyTree")